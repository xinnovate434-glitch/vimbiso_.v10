import { useEffect, useMemo, useState } from "react";
import {
  ChevronLeft,
  Mic,
  Search,
  Repeat,
  Users,
  Smartphone,
  BatteryLow,
  User,
  ShoppingBag,
  Package,
  CheckCircle2,
  CloudSun,
} from "lucide-react";
import {
  CATS,
  DICT,
  IMG,
  NEAR,
  OFFERS,
  PORTRAITS,
  QUALITIES,
  TICKER,
  UNITS,
  fairBadge,
  money,
} from "@/lib/vimbiso/data";
import { useVimbiso } from "@/lib/vimbiso/store";
import { fetchWeather, weatherAdvice, type WeatherNow } from "@/lib/vimbiso/weather";
import {
  Avatar,
  Badge,
  Btn,
  Card,
  Choice,
  Field,
  IconBtn,
  Input,
  Pad,
  Photo,
  Stars,
  Steps,
  TopBar,
  Wordmark,
} from "./primitives";
import { MapHeat } from "./map-heat";
import { cn } from "@/lib/utils";

export function HomeScreen() {
  const s = useVimbiso();
  const t = DICT[s.lang];
  const ticker = useMemo(() => [...TICKER, ...TICKER], []);
  const [weather, setWeather] = useState<WeatherNow | null>(null);
  const [heat, setHeat] = useState<{ id: string; name: string; intensity: number; traders: number }[]>([]);

  useEffect(() => {
    const city = s.city || "Harare";
    fetchWeather(city).then(setWeather);
    import("@/lib/vimbiso/heatmap").then(({ buildHeatCells }) => {
      buildHeatCells().then(setHeat).catch(() => {});
    });
  }, [s.city]);

  return (
    <section className="vn-screen">
      <Photo src={IMG.home} alt="Leafy greens stacked at a produce market" overlay="header" className="hero" />
      <div className="relative z-[2] -mt-[280px]">
        <div className="flex items-center justify-between px-4 pt-[max(env(safe-area-inset-top),10px)] h-14">
          <div className="flex items-center gap-2.5">
            <Wordmark dark />
            <span className="inline-flex items-center gap-1.5 text-[11px] font-extrabold text-teal-2">
              <i className="vn-live" /> live
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="inline-flex overflow-hidden rounded-[10px] border border-white/30 bg-white/10">
              {(["en", "sn"] as const).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => s.setLang(l)}
                  className={
                    s.lang === l
                      ? "bg-white px-2 py-1 text-[10px] font-extrabold text-navy"
                      : "px-2 py-1 text-[10px] font-extrabold text-white/80"
                  }
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
            <IconBtn light onClick={() => { s.toggleLite(); s.toastMsg(s.lite ? "Lite mode off" : "Lite mode on — saving data"); }}>
              <BatteryLow className="size-[18px]" />
            </IconBtn>
            <IconBtn light onClick={() => s.go("profile")}>
              <User className="size-[18px]" />
            </IconBtn>
          </div>
        </div>
        <div className="px-[18px] pt-4 pb-5">
          <p className="text-[13px] font-semibold text-white/80">{t.hello}</p>
          <h1 className="font-display mt-1 text-[28px] font-extrabold text-white">{t.need}</h1>
          <div className="mt-4 flex items-center gap-2.5 rounded-[18px] bg-white py-1.5 pr-1.5 pl-4 shadow-[var(--shadow-lift)]">
            <Search className="size-5 shrink-0 text-mut" />
            <input
              value={s.search}
              onChange={(e) => s.set({ search: e.target.value })}
              placeholder="Tomatoes, charger, plumber…"
              className="min-w-0 flex-1 border-0 bg-transparent text-base outline-none"
            />
            <button
              type="button"
              onClick={async () => {
                s.set({ voiceOn: true });
                try {
                  const { canListen, listenOnce, speak } = await import("@/lib/vimbiso/voice");
                  if (!canListen()) {
                    s.toastMsg("Voice not supported on this device — type your need instead");
                    return;
                  }
                  s.toastMsg("Listening…");
                  const text = await listenOnce("en-US");
                  if (text) {
                    s.set({ search: text, bidItem: text });
                    s.toastMsg(`Heard: ${text}`);
                    speak(`You need ${text}`);
                  }
                } catch (e) {
                  s.toastMsg(e instanceof Error ? e.message : "Voice failed");
                } finally {
                  s.set({ voiceOn: false });
                }
              }}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-gradient-to-br from-teal to-teal-2 text-white shadow-[0_6px_16px_rgb(15_118_110_/_0.35)]"
              aria-label="Search by voice"
            >
              <Mic className="size-5" />
            </button>
            <button
              type="button"
              onClick={() => s.go("bid")}
              className="rounded-[13px] bg-teal px-4 py-3 text-sm font-extrabold text-white"
            >
              {t.buildbid}
            </button>
          </div>
          <div className="mt-3.5 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                s.set({
                  bidItems: [
                    {
                      name: "Tomatoes",
                      quality: "Premium",
                      qty: 20,
                      unit: "kg",
                      price: 15,
                      total: 300,
                      photo: IMG.tomatoes,
                    },
                  ],
                });
                s.toastMsg("Loaded your last order");
                s.go("basket");
              }}
              className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-line bg-white px-3.5 py-2 text-xs font-bold text-navy shadow-[var(--shadow-card)]"
            >
              <Repeat className="size-3.5" /> Reorder: 20kg tomatoes
            </button>
            <button
              type="button"
              onClick={() => s.go("bid")}
              className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-line bg-white px-3.5 py-2 text-xs font-bold text-navy shadow-[var(--shadow-card)]"
            >
              <Users className="size-3.5" /> Pool a group buy
            </button>
            <button
              type="button"
              onClick={() => s.go("ussd")}
              className="inline-flex items-center gap-1.5 rounded-full border-[1.5px] border-line bg-white px-3.5 py-2 text-xs font-bold text-navy shadow-[var(--shadow-card)]"
            >
              <Smartphone className="size-3.5" /> USSD mode
            </button>
          </div>
        </div>
      </div>
      <div className="px-4 pb-24">
        <div className="flex overflow-hidden rounded-md bg-navy text-white shadow-[var(--shadow-card)]">
          {[
            ["—", t.online],
            ["—", t.matched],
            [s.rating ? s.rating.toFixed(1) : "—", t.rating],
          ].map(([v, k], i) => (
            <div key={k} className="relative flex-1 px-1.5 py-3 text-center">
              {i > 0 ? <i className="absolute top-[18%] left-0 h-[64%] w-px bg-white/16" /> : null}
              <div className="font-display text-[17px] font-extrabold text-gold-2">{v}</div>
              <div className="mt-0.5 text-[10px] font-semibold text-white/70">{k}</div>
            </div>
          ))}
        </div>

        {/* Live weather */}
        {weather ? (
          <Card className="mt-3.5 flex items-center gap-3 bg-gradient-to-r from-navy/5 to-teal/5">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-teal/15 text-teal">
              <CloudSun className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-2">
                <span className="font-display text-xl font-extrabold text-navy">
                  {weather.temp}°C
                </span>
                <span className="text-xs font-semibold text-mut capitalize">
                  {weather.description} · {weather.city}
                </span>
              </div>
              <p className="mt-0.5 text-[11px] text-mut">
                {weatherAdvice(weather, s.role === "trader" ? "trader" : s.role === "delivery" ? "delivery" : "buyer")}
              </p>
            </div>
          </Card>
        ) : null}

        {/* Pending approval banner */}
        {s.userStatus === "pending" && s.userId ? (
          <div className="mt-3 rounded-lg border border-gold/40 bg-gold/10 px-3.5 py-2.5 text-xs font-semibold text-gold-d">
            Your account is waiting for admin approval. You can browse, but trading unlocks after approval.
          </div>
        ) : null}

        {/* Demand heat map (cells) */}
        {heat.length > 0 ? (
          <Card className="mt-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-extrabold tracking-[0.08em] text-mut uppercase">
                Demand heat map
              </span>
              <button type="button" onClick={() => s.go("radar")} className="text-xs font-bold text-teal">
                Open radar
              </button>
            </div>
            <div className="mt-2.5 grid grid-cols-3 gap-1.5">
              {heat.slice(0, 9).map((c) => (
                <div
                  key={c.id}
                  className="rounded-md px-2 py-2 text-center"
                  style={{
                    background: `rgba(15, 118, 110, ${0.12 + c.intensity * 0.55})`,
                  }}
                >
                  <div className="text-[10px] font-bold leading-tight text-navy">{c.name}</div>
                  <div className="text-[9px] text-mut">{c.traders} traders</div>
                </div>
              ))}
            </div>
            <div className="mt-3 overflow-hidden rounded-lg">
              <MapHeat height={220} />
            </div>
          </Card>
        ) : null}

        {/* Quick actions */}
        <div className="mt-3.5 grid grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => s.go("bid")}
            className="flex flex-col items-center gap-1.5 rounded-lg bg-white px-2 py-3 shadow-[var(--shadow-card)] transition hover:-translate-y-0.5 active:scale-[0.98]"
          >
            <span className="grid h-10 w-10 place-items-center rounded-full bg-teal/12 text-teal">
              <ShoppingBag className="size-5" strokeWidth={2.2} />
            </span>
            <span className="text-[11px] font-extrabold text-navy">New bid</span>
          </button>
          <button
            type="button"
            onClick={() => s.go("radar")}
            className="flex flex-col items-center gap-1.5 rounded-lg bg-white px-2 py-3 shadow-[var(--shadow-card)] transition hover:-translate-y-0.5 active:scale-[0.98]"
          >
            <span className="grid h-10 w-10 place-items-center rounded-full bg-navy/8 text-navy">
              <Search className="size-5" strokeWidth={2.2} />
            </span>
            <span className="text-[11px] font-extrabold text-navy">Scan radar</span>
          </button>
          <button
            type="button"
            onClick={() => s.go("status")}
            className="flex flex-col items-center gap-1.5 rounded-lg bg-white px-2 py-3 shadow-[var(--shadow-card)] transition hover:-translate-y-0.5 active:scale-[0.98]"
          >
            <span className="grid h-10 w-10 place-items-center rounded-full bg-gold/15 text-gold-d">
              <Package className="size-5" strokeWidth={2.2} />
            </span>
            <span className="text-[11px] font-extrabold text-navy">My orders</span>
          </button>
        </div>

        <div className="vn-ticker mt-3">
          <div className="vn-ticker-track">
            {ticker.map((item, i) => (
              <span key={i} className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-navy">
                <i className="h-1.5 w-1.5 rounded-full bg-teal-2" />
                {item}
              </span>
            ))}
          </div>
        </div>
        <div className="mt-4.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold tracking-[0.08em] text-mut uppercase">{t.categories}</span>
            <button type="button" onClick={() => s.go("bid")} className="text-xs font-bold text-teal">
              {t.buildbid2}
            </button>
          </div>
          <div className="mt-2.5 grid grid-cols-4 gap-2.5">
            {CATS.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  s.set({ bidCat: c.id, bidStep: 1 });
                  s.go("bid");
                }}
                className="overflow-hidden rounded-md bg-white text-center shadow-[var(--shadow-card)] transition hover:-translate-y-0.5 active:scale-[0.98]"
              >
                <img src={c.photo} alt="" className="h-14 w-full object-cover" />
                <div className="px-1 py-2 text-[11px] font-bold leading-tight text-navy">{c.name}</div>
              </button>
            ))}
          </div>
        </div>
        <div className="mt-4.5">
          <span className="text-[11px] font-extrabold tracking-[0.08em] text-mut uppercase">{t.toptraders}</span>
          <div className="mt-2.5 grid gap-3">
            {NEAR.length === 0 ? (
              <Card key="empty-near">
                <div className="text-sm font-bold text-navy">No traders on the network yet</div>
                <p className="mt-1 text-xs text-mut">Post a bid — real traders respond. No demo profiles.</p>
                <button type="button" className="mt-3 text-xs font-bold text-teal" onClick={() => s.go("bid")}>Build a bid</button>
              </Card>
            ) : NEAR.map((n) => (
              <Card key={n.name} onClick={() => s.go("bid")}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar src={n.img} alt={n.name} verified />
                    <div>
                      <div className="font-extrabold text-navy">{n.name}</div>
                      <div className="text-xs text-mut">
                        {n.stock} · {n.dist}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge tone="gold">Trust {n.trust}</Badge>
                    <div className="mt-1 flex items-center justify-end gap-1">
                      <Stars value={n.rating} />
                      <span className="text-xs text-mut">{n.rating}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function BidScreen() {
  const s = useVimbiso();
  const tot = s.bidQty * s.bidPrice;
  return (
    <section className="vn-screen">
      <Photo src={IMG.tomatoes} alt="Fresh tomatoes" overlay="soft" className="absolute inset-0 opacity-80" />
      <TopBar
        left={
          <IconBtn onClick={() => s.go("home")}>
            <ChevronLeft />
          </IconBtn>
        }
        title="Build your bid"
        right={<Badge>{s.bidItems.length} items</Badge>}
      />
      <Pad className="relative z-[2]">
        <Steps total={4} current={s.bidStep} />
        {s.bidStep === 1 && (
          <>
            <h1 className="font-display text-[26px] font-extrabold tracking-[-0.03em] text-navy">What do you need?</h1>
            <p className="mt-1.5 mb-3.5 text-mut">Add items to your bid. Traders respond to your exact request.</p>
            <Field label="Item name">
              <Input value={s.bidItem} onChange={(e) => s.set({ bidItem: e.target.value })} />
            </Field>
            <div className="mt-2.5">
              <span className="mb-2 block text-[11px] font-extrabold uppercase tracking-[0.08em] text-mut">
                Category
              </span>
              <div className="grid grid-cols-4 gap-2.5">
                {CATS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => s.set({ bidCat: c.id })}
                    className={cn(
                      "overflow-hidden rounded-md border-[1.5px] bg-white text-center",
                      s.bidCat === c.id ? "border-teal bg-teal/6" : "border-transparent",
                    )}
                  >
                    <img src={c.photo} alt="" className="h-12 w-full object-cover" />
                    <div className="px-1 py-1.5 text-[11px] font-bold text-navy">{c.name}</div>
                  </button>
                ))}
              </div>
            </div>
            <Btn className="mt-4" onClick={() => s.set({ bidStep: 2 })}>
              Continue
            </Btn>
          </>
        )}
        {s.bidStep === 2 && (
          <>
            <h1 className="font-display text-[26px] font-extrabold tracking-[-0.03em] text-navy">Quality standard</h1>
            <p className="mt-1.5 mb-3.5 text-mut">Tell traders exactly what grade you expect.</p>
            <div className="grid grid-cols-3 gap-2.5">
              {QUALITIES.map((q) => (
                <button
                  key={q.id}
                  type="button"
                  onClick={() => s.set({ bidQuality: q.id })}
                  className={cn(
                    "relative overflow-hidden rounded-[18px] border-2 bg-white px-2 py-4 text-center",
                    s.bidQuality === q.id ? "border-teal bg-teal/8" : "border-line",
                  )}
                >
                  {s.bidQuality === q.id ? (
                    <span className="absolute top-0 right-0 rounded-bl-[10px] bg-teal px-2 py-0.5 text-[9px] font-extrabold text-white">
                      Selected
                    </span>
                  ) : null}
                  <div className="font-extrabold text-navy">{q.name}</div>
                  <div className="mt-0.5 text-[10px] text-mut">{q.detail}</div>
                </button>
              ))}
            </div>
            <div className="mt-4 flex gap-2">
              <Btn variant="ghost" className="w-auto" onClick={() => s.set({ bidStep: 1 })}>
                Back
              </Btn>
              <Btn onClick={() => s.set({ bidStep: 3 })}>Continue</Btn>
            </div>
          </>
        )}
        {s.bidStep === 3 && (
          <>
            <h1 className="font-display text-[26px] font-extrabold tracking-[-0.03em] text-navy">How many?</h1>
            <p className="mt-1.5 mb-3.5 text-mut">Set the quantity you need.</p>
            <div className="my-5 flex justify-center">
              <div className="flex overflow-hidden rounded-sm border-[1.5px] border-line bg-white">
                <button
                  type="button"
                  className="grid h-11 w-11 place-items-center bg-paper text-xl font-extrabold text-navy"
                  onClick={() => s.set({ bidQty: Math.max(1, s.bidQty - 1) })}
                >
                  −
                </button>
                <div className="font-display grid h-11 w-14 place-items-center border-x-[1.5px] border-line text-[22px] font-extrabold text-navy">
                  {s.bidQty}
                </div>
                <button
                  type="button"
                  className="grid h-11 w-11 place-items-center bg-paper text-xl font-extrabold text-navy"
                  onClick={() => s.set({ bidQty: s.bidQty + 1 })}
                >
                  +
                </button>
              </div>
            </div>
            <span className="mb-2 block text-[11px] font-extrabold uppercase tracking-[0.08em] text-mut">Unit</span>
            <div className="flex flex-wrap gap-2">
              {UNITS.map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => s.set({ bidUnit: u })}
                  className={cn(
                    "rounded-sm border-[1.5px] px-3.5 py-2.5 text-[13px] font-bold",
                    s.bidUnit === u ? "border-teal bg-teal/6 text-navy" : "border-line bg-white text-navy",
                  )}
                >
                  {u}
                </button>
              ))}
            </div>
            <div className="mt-4 flex gap-2">
              <Btn variant="ghost" className="w-auto" onClick={() => s.set({ bidStep: 2 })}>
                Back
              </Btn>
              <Btn onClick={() => s.set({ bidStep: 4 })}>Continue</Btn>
            </div>
          </>
        )}
        {s.bidStep === 4 && (
          <>
            <h1 className="font-display text-[26px] font-extrabold tracking-[-0.03em] text-navy">Your price</h1>
            <p className="mt-1.5 mb-3.5 text-mut">Set what you're willing to pay. Traders can accept or counter.</p>
            <div className="my-5 text-center">
              <div className="font-display text-[32px] font-extrabold text-navy">{money(s.bidPrice)}</div>
              <div className="text-xs text-mut">
                per unit · total <b>{money(tot)}</b>
              </div>
            </div>
            <input
              type="range"
              className="vn-range"
              min={1}
              max={200}
              step={0.5}
              value={s.bidPrice}
              onChange={(e) => s.set({ bidPrice: parseFloat(e.target.value) })}
            />
            <div className="mt-1 flex justify-between text-xs text-mut">
              <span>$1</span>
              <span>$200</span>
            </div>
            <Card className="mt-4 bg-paper">
              <span className="text-[11px] font-extrabold tracking-[0.08em] text-mut uppercase">Bid summary</span>
              <div className="mt-2 flex justify-between text-sm">
                <span className="text-mut">Item</span>
                <b>{s.bidItem}</b>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-mut">Quality</span>
                <Badge tone="gold" className="capitalize">
                  {s.bidQuality}
                </Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-mut">Quantity</span>
                <b>
                  {s.bidQty} {s.bidUnit}
                </b>
              </div>
              <div className="my-2 h-px bg-line" />
              <div className="flex justify-between">
                <span className="font-extrabold text-navy">Total bid</span>
                <span className="font-display text-[22px] font-extrabold text-navy">{money(tot)}</span>
              </div>
            </Card>
            <button
              type="button"
              onClick={() => {
                s.set({
                  bidItems: [
                    ...s.bidItems,
                    {
                      name: s.bidItem,
                      quality: s.bidQuality,
                      qty: s.bidQty,
                      unit: s.bidUnit,
                      price: s.bidPrice,
                      total: +(s.bidPrice * s.bidQty).toFixed(2),
                      photo: s.bidCat === "veg" ? IMG.tomatoes : IMG.fruit,
                    },
                  ],
                  bidStep: 1,
                });
                s.toastMsg(`${s.bidItem} added to your bid`);
              }}
              className="mt-4 w-full rounded-[20px] bg-gradient-to-br from-teal to-teal-2 py-[18px] text-[17px] font-extrabold text-white shadow-[0_12px_30px_rgb(15_118_110_/_0.35)]"
            >
              Add to bid
            </button>
            <div className="mt-2.5 flex gap-2">
              <Btn variant="ghost" className="w-auto" onClick={() => s.set({ bidStep: 3 })}>
                Back
              </Btn>
              <Btn variant="ghost" className="w-auto" onClick={() => s.go("basket")}>
                View basket ({s.bidItems.length})
              </Btn>
            </div>
          </>
        )}
      </Pad>
      {s.bidItems.length > 0 ? (
        <div className="fixed bottom-20 left-1/2 z-20 w-[calc(100%-32px)] max-w-[398px] -translate-x-1/2 rounded-[22px] bg-gradient-to-br from-navy to-navy-2 px-[18px] py-4 text-white shadow-[var(--shadow-lift)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-gold text-base font-black text-navy-3">
                {s.bidItems.length}
              </span>
              <div>
                <div className="text-sm font-extrabold">Your bid</div>
                <div className="text-xs text-white/60">
                  {s.bidItems.length} item{s.bidItems.length === 1 ? "" : "s"}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="font-display text-xl font-extrabold text-gold-2">
                {money(s.bidItems.reduce((a, i) => a + i.total, 0))}
              </div>
              <button
                type="button"
                onClick={() => s.go("basket")}
                className="rounded-sm bg-teal px-4 py-3 text-sm font-extrabold"
              >
                View
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}

export function BasketScreen() {
  const s = useVimbiso();
  const tot = s.bidItems.reduce((a, i) => a + i.total, 0);
  return (
    <section className="vn-screen">
      <Photo src={IMG.welcome} alt="Market crates" overlay="soft" className="absolute inset-0 opacity-60" />
      <TopBar
        left={
          <IconBtn onClick={() => s.go("bid")}>
            <ChevronLeft />
          </IconBtn>
        }
        title="Your bid"
      />
      <Pad className="relative z-[2]">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy to-navy-2 p-[22px] text-white">
          <div className="text-xs text-white/60">Total bid value</div>
          <div className="font-display text-4xl font-extrabold text-gold-2">{money(tot)}</div>
          <div className="mt-2.5 flex flex-wrap gap-2">
            <Badge tone="glass">{s.bidItems.length} items</Badge>
            <Badge tone="gold">Chitungwiza</Badge>
            <Badge tone="glass">Now</Badge>
          </div>
        </div>
        <Btn variant="outline" className="mt-3" onClick={() => s.set({ poolOpen: true, poolJoined: 3 })}>
          Pool this bid with neighbours
        </Btn>
        <div className="mt-4 mb-2.5 flex justify-between">
          <span className="text-[11px] font-extrabold tracking-[0.08em] text-mut uppercase">Items in your bid</span>
          <button type="button" className="text-xs font-bold text-teal" onClick={() => s.go("bid")}>
            + Add more
          </button>
        </div>
        {s.bidItems.length === 0 ? (
          <div className="py-10 text-center">
            <h2 className="font-display text-xl font-extrabold text-navy">Your bid is empty</h2>
            <p className="mt-1.5 text-mut">Add items to tell traders exactly what you need.</p>
            <Btn variant="teal" className="mx-auto mt-4 w-auto px-6" onClick={() => s.go("bid")}>
              Build your bid
            </Btn>
          </div>
        ) : (
          <div className="grid gap-3">
            {s.bidItems.map((it, i) => (
              <Card key={i}>
                <div className="flex items-center gap-3">
                  <img src={it.photo} alt="" className="h-12 w-12 rounded-sm object-cover" />
                  <div className="min-w-0 flex-1">
                    <div className="font-extrabold text-navy">{it.name}</div>
                    <div className="text-[11px] text-mut">
                      {it.qty} {it.unit} · {it.quality} · {money(it.price)}/unit
                    </div>
                  </div>
                  <div className="font-display text-lg font-extrabold text-navy">{money(it.total)}</div>
                  <button
                    type="button"
                    onClick={() => s.set({ bidItems: s.bidItems.filter((_, j) => j !== i) })}
                    className="grid h-8 w-8 place-items-center rounded-full bg-err/10 text-err"
                    aria-label="Remove"
                  >
                    ×
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
        <Btn
          className="mt-4"
          disabled={s.bidItems.length === 0}
          onClick={async () => {
            if (s.userId) {
              const { createBid } = await import("@/lib/vimbiso/api");
              const { data, error } = await createBid({
                buyerId: s.userId,
                items: s.bidItems,
                city: s.city,
              });
              if (error) {
                s.toastMsg("Bid saved locally — check DB");
              } else if (data?.[0]) {
                s.toastMsg("Bid posted to the network");
              }
            }
            s.go("radar");
          }}
        >
          Find traders for this bid
        </Btn>
      </Pad>
    </section>
  );
}


export function RadarScreen() {
  const s = useVimbiso();
  const [km, setKm] = useState(0.1);
  const [st, setSt] = useState("Getting your location…");
  const [found, setFound] = useState<
    { id: string; n: string; distKm: number; a: number; r: number; lk: boolean; city?: string }[]
  >([]);
  const [done, setDone] = useState(false);
  const [myPos, setMyPos] = useState<{ lat: number; lon: number } | null>(null);

  useEffect(() => {
    let cancelled = false;
    const timers: number[] = [];

    function haversineKm(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
      const R = 6371;
      const dLat = ((b.lat - a.lat) * Math.PI) / 180;
      const dLon = ((b.lon - a.lon) * Math.PI) / 180;
      const la1 = (a.lat * Math.PI) / 180;
      const la2 = (b.lat * Math.PI) / 180;
      const x =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(la1) * Math.cos(la2) * Math.sin(dLon / 2) ** 2;
      return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
    }

    async function run() {
      // 1) GPS
      let origin = { lat: -17.8292, lon: 31.0522 }; // Harare fallback only for map center
      try {
        const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
          if (!navigator.geolocation) reject(new Error("no-geo"));
          else
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              enableHighAccuracy: true,
              timeout: 12000,
            });
        });
        origin = { lat: pos.coords.latitude, lon: pos.coords.longitude };
        if (!cancelled) {
          setMyPos(origin);
          setSt("Location locked — scanning network…");
        }
      } catch {
        if (!cancelled) setSt("Location unavailable — scanning by city only…");
      }

      // 2) Real traders from Supabase (no demo names)
      type T = {
        id: string;
        name: string;
        city: string;
        trust_score: number;
        rating: number;
        vimbiso_id: string | null;
        lat?: number | null;
        lon?: number | null;
      };
      let traders: T[] = [];
      try {
        const { listOnlineTraders } = await import("@/lib/vimbiso/api");
        const { data } = await listOnlineTraders();
        traders = (data || []).filter((u) => u.id !== s.userId);
      } catch {
        traders = [];
      }

      // Estimate distance: if no lat/lon on user, use coarse city match (same city = 0.5–3 km random-stable, else far)
      const withDist = traders.map((t, i) => {
        let distKm = 50;
        if (typeof t.lat === "number" && typeof t.lon === "number") {
          distKm = haversineKm(origin, { lat: t.lat, lon: t.lon });
        } else if (t.city && s.city && t.city.toLowerCase() === s.city.toLowerCase()) {
          // same city, unknown exact coords — place between 0.3 and 4 km deterministically
          distKm = 0.3 + ((i * 17) % 37) / 10;
        } else {
          distKm = 15 + ((i * 13) % 40); // outside progressive reveal until range grows (user may stop earlier)
        }
        const a = (i * 47) % 360;
        const r = Math.min(0.85, 0.25 + distKm / 20);
        return {
          id: t.id,
          n: t.name || t.vimbiso_id || "Trader",
          distKm,
          a,
          r,
          lk: false,
          city: t.city,
        };
      });

      // 3) Progressive rings: 100m → 200m → … up to 20 km then stop
      const rings = [
        0.1, 0.2, 0.3, 0.5, 0.8, 1, 1.5, 2, 3, 5, 8, 12, 15, 20,
      ];
      let revealed = new Set<string>();

      for (let i = 0; i < rings.length; i++) {
        if (cancelled) return;
        const ring = rings[i];
        const label =
          ring < 1
            ? `Scanning ${Math.round(ring * 1000)} m…`
            : `Scanning ${ring} km…`;
        setKm(ring);
        setSt(label);

        const newly = withDist.filter((t) => t.distKm <= ring && !revealed.has(t.id));
        for (const t of newly) {
          revealed.add(t.id);
          setFound((cur) => {
            if (cur.some((x) => x.id === t.id)) return cur;
            return [...cur, { ...t, lk: false }];
          });
          await new Promise((r) => {
            timers.push(window.setTimeout(r, 280));
          });
          setFound((cur) => cur.map((x) => (x.id === t.id ? { ...x, lk: true } : x)));
        }

        await new Promise((r) => {
          timers.push(window.setTimeout(r, 450));
        });
      }

      if (!cancelled) {
        setDone(true);
        setSt(
          revealed.size
            ? `Scan complete — ${revealed.size} within range`
            : "Scan complete — no network users in range yet",
        );
      }
    }

    void run();
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [s.userId, s.city]);

  return (
    <section className="vn-screen p-0">
      <div className="vn-radar">
        <div className="vn-radar-map">
          <img src={IMG.radar} alt="Scanning the live network" />
        </div>
        <div className="vn-radar-grid" />
        <div className="absolute top-[max(env(safe-area-inset-top),18px)] right-0 left-0 z-[6] px-[18px] text-center">
          <div className="text-xs font-semibold text-white/70">
            {s.city || "Your area"} · real network only
          </div>
          <div className="font-display mt-1 text-[20px] font-extrabold text-white">{st}</div>
        </div>
        <div className="vn-dish">
          <div className="vn-ring" />
          <div className="vn-ring r2" />
          <div className="vn-ring r3" />
          <div className="vn-ring r4" />
          <div className="vn-pulse" />
          <div className="vn-pulse p2" />
          <div className="vn-pulse p3" />
          <div className="vn-cross absolute inset-0" />
          <div className="vn-sweep" />
          <div
            className="absolute top-1/2 left-1/2 z-[3] -translate-x-1/2 -translate-y-1/2 text-[9px] font-bold text-teal-2"
            style={{ transform: `translate(-50%, -50%) scale(${0.55 + Math.min(km, 12) / 18})` }}
          >
            {km < 1 ? `${Math.round(km * 1000)} m` : `${km} km`}
          </div>
          <div className="vn-center" />
          {found.map((f) => {
            const x = 50 + Math.cos((f.a * Math.PI) / 180) * f.r * 46;
            const y = 50 + Math.sin((f.a * Math.PI) / 180) * f.r * 46;
            return (
              <div
                key={f.id}
                className={cn("vn-blip in", f.lk && "lk")}
                style={{ left: `${x}%`, top: `${y}%` }}
              >
                <span>
                  {f.n} · {f.distKm < 1 ? `${Math.round(f.distKm * 1000)}m` : `${f.distKm.toFixed(1)}km`}
                </span>
              </div>
            );
          })}
        </div>
        <div className="absolute right-0 bottom-8 left-0 z-[6] px-6 text-center">
          <div className="font-display text-[28px] font-extrabold text-gold-2">
            {found.filter((f) => f.lk).length} found
          </div>
          <div className="mt-0.5 text-xs text-white/65">
            Only appears when the scan reaches their distance — no demo people
          </div>
          <button
            type="button"
            onClick={() => s.go(done ? "offers" : "home")}
            className="mt-4 inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-5 py-2.5 text-sm font-bold text-white backdrop-blur-sm transition hover:bg-white/20"
          >
            {done ? "See offers" : "Stop scan"}
          </button>
        </div>
      </div>
    </section>
  );
}

export function 